package com.jaxrs.example.catalog;

import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;

@ApplicationPath("/catalog-service")
public class Catalog extends Application {

}
