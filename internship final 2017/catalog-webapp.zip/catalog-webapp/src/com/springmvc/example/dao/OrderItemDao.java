package com.springmvc.example.dao;

import com.springmvc.example.model.OrderItem;

public interface OrderItemDao {

	public void save(OrderItem orderItem);
	
}
