package com.springmvc.example.dao;

import com.springmvc.example.model.Order;

public interface OrderDao {
	
	public void save(Order o);

}
